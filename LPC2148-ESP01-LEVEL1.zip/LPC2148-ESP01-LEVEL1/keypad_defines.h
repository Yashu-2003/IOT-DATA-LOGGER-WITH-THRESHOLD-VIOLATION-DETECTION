#ifndef __KEYPAD_DEFINES_H__
#define __KEYPAD_DEFINES_H__

#define ROW0   16 //p1.16
#define ROW1   17
#define ROW2   18
#define ROW3   19

#define COL0   20
#define COL1   21
#define COL2   22
#define COL3   23

#endif
